library(testthat)
library(StackTweetBot)

test_check("StackTweetBot")
